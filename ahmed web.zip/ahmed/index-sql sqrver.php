<?php
$serverName = "DESKTOP-LR78UU3\SQLEXPRESS"; 
$user_name = "ahmed";
$user_Password = "123";
$name_db = "phonedb";
$connectionInfo = array( "Database"=>$name_db, "UID"=>$user_name, "PWD"=>$user_Password);
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     echo "Connection established.<br />";
}else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}

echo "Connected successfully <br>";

$number = $_POST['id'];
$time = $_POST['Number'];
// echo "id = ".$name ;
// echo "age = ".$age ;
$query = "INSERT INTO phone (phone_number,time1) VALUES ('$number','$time')";
$result = sqlsrv_query($conn,$query);
if($result == 1 ){
    $sendBack['success']= "true";
    $sendBack['message'] = "Data Enter Successfully";
    $myJson = json_encode($sendBack);
    echo $myJson;

}else {
    echo "coud not execute query";
 }
 sqlsrv_close($conn);
 echo"end";
?>
?>