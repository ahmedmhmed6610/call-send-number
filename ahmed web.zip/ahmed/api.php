<?php
$servername = "localhost";
$username = "root";
$passwprd = "";
$db_name = "number_phonedb";

$conn =mysqli_connect($servername,$username,$passwprd) or die("connection Die");
$select_db = mysqli_select_db($conn,$db_name) or die("could not connect with the database");


$sth = mysqli_query($conn, "SELECT * from phone ");
$rows = array();
while($r = mysqli_fetch_assoc($sth)) {
    $rows[] = $r;
}

//print json_encode($rows);
echo json_encode($rows);
//print_r($rows);




mysqli_close($conn);


?>
