<?php
$servername = "localhost";
$username = "root";
$passwprd = "";
$db_name = "number_phonedb";

$conn =mysqli_connect($servername,$username,$passwprd) or die("connection Die");
$select_db = mysqli_select_db($conn,$db_name) or die("could not connect with the database");
echo "Connected successfully";
echo "<br>" ;
$number = $_POST['number'];
$time = $_POST['time'];

// echo "number = ".$number ;
// echo "time = ".$time ;

$query = "INSERT INTO phone (number, time)VALUES ('$number', '$time')";
$query = "INSERT INTO phone (number,time) VALUES ('ahmed','ahmed')";
$result = mysqli_query($conn,$query);
if($result == 1 ){
    $sendBack['success']= "true";
    $sendBack['message'] = "Data Enter Successfully";
    $myJson = json_encode($sendBack);
    echo $myJson;

}else {
    echo "coud not execute query";
 }



// $myArr = array('number',$number, 'time', $time);
// $myJSON = json_encode($myArr);

// echo "number : ".$number;


// $sth = mysqli_query($conn, "SELECT * from phone ");
// $rows = array();
// while($r = mysqli_fetch_assoc($sth)) {
//     $rows[] = $r;
// }
print json_encode($number);
echo $time;


// mysqli_close($conn);
// echo"end";

?>
